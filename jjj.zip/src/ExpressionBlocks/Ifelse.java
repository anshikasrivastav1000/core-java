package ExpressionBlocks;

public class Ifelse {

    public static  void main (String[] args){

        boolean primeSubs  = false;

        if(primeSubs == true){
            System.out.println("welcome");
        }else {
            System.out.println("subscride now");
        }


    }
}
