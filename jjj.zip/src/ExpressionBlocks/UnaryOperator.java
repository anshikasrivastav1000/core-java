package ExpressionBlocks;

public class UnaryOperator {
    public static  void main(String[] args){
        int var1=5,var2=5;

        System.out.println(var1++);
        System.out.println(++var2);

    }
}
