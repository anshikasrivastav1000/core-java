package ExpressionBlocks;

public class AssignmentOperators {

    public  static void main(String[] args){

        int age;
        age =5;

        int a = 20;
        int val =age;
        val +=a;
//        val -=a;
//        val *=a;
//        val /=a;
//        val %=a;


        System.out.println(val);
    }


}
