package ExpressionBlocks;

public class RelationalOperators {

    public static  void main(String[] args){

        //relational operators will return true or false

        int a = 8,b=20;

        System.out.println(a==b);
        System.out.println(a!=b);
        System.out.println(a>=b);
        System.out.println(a<=b);
        System.out.println(a>=b);
        System.out.println(a<=b);


    }
}
