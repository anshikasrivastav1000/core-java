package ExpressionBlocks;
import  java.util.Scanner;
public class inputOutput {
    public static void main (String[] args){
//
//        System.out.println("helloo");
//        int val= 10;
//
//        System.out.println(val);
//        System.out.println(5);
//
//        System.out.println("I am " + "kind");
//        System.out.println("Number =" + val); //number = 10


//        Scanner input = new Scanner(System.in);
//
//        System.out.println("enter an integer value : " );
//        int number = input.nextInt();
//
//        System.out.println("you entered " + number);

//
//        float myfloat = input.nextFloat();
//
//        double myDouble = input.nextDouble();
//
//        String myString = input.next();

        Scanner Input = new Scanner(System.in);

        System.out.println("enter some line");
        String text = Input.nextLine();

        System.out.println("some text" + text);


    }


}
