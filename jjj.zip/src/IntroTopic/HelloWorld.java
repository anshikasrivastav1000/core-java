package IntroTopic;

public class HelloWorld {
    public static void main(String[] args){

System.out.println("hello world");
        System.out.println("hello world");
        System.out.print("1 print");
        System.out.print("2 print");
        System.out.println();

        System.out.printf("Hello %s, you have %d new messages.", "Alice", 5);




 }

}
