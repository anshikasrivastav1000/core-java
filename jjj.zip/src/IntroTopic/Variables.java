package IntroTopic;

public class Variables {
    public static void main(String[] args) {
        int speed = 20;
    }
}
